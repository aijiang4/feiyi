<template>
    <app-layout>
        <view v-if="status == 1">
            <!-- 用户信息开始 -->
            <view class="info" :style="{'background-image': 'url('+share_setting.pic_url_home_head + ')'}">
                <view v-if="userInfo" class="user-info dir-left-nowrap cross-center">
                    <image class="user-avatar box-grow-0" :src="userInfo.avatar"></image>
                    <view class="box-grow-1 dir-top-nowrap main-center">
                        <view class="user-name t-omit">{{name ? name:userInfo.nickname}}</view>
                        <view class="mtb-10 t-omit" v-if="is_show_parent_name">{{custom_setting.words.parent_name.name}}：{{userInfo.identity.parent_name}}</view>
                        <view v-if="index">{{custom_setting.words.level_name.name}}：{{index.level_name ? index.level_name : '无'}}</view>
                    </view>
                    <view class="box-grow-0" v-if="share_setting.is_show_share_level == 1"
                          @click="$jump({url: '/pages/share/level/level?name=' + index.level_name, open_type: 'navigate'})">升级条件</view>
                    <image class="box-grow-0 arrow-right" v-if="share_setting.is_show_share_level == 1"
                           src="/static/image/icon/arrow-right-white.png"></image>
                </view>
                <view class="share-info">
                    <view>{{custom_setting.words.can_be_presented.name}}</view>
                    <view>
                        <text style="font-family:DIN">{{index.money?index.money:0}}</text>元</view>
                </view>
                <view @click="jump('/pages/share/cash/cash?type=share&money=' + index.money)">
                    <view class="withdraw-btn">{{custom_setting.words.cash.name}}</view>
                </view>
            </view>
            <!-- 佣金情况开始 -->
            <view class="nav main-between cross-center">
                <view class="nav-left">
                    <view class="nav-title">{{custom_setting.words.already_presented.name}}</view>
                    <view>{{index.cash_money?index.cash_money:0}}元</view>
                </view>
                <view>
                    <view class="nav-title">{{custom_setting.words.order_money_un.name}}</view>
                    <view>{{index.order_money_un?index.order_money_un:0}}元</view>
                </view>
            </view>
            <!-- 功能菜单开始 -->
            <view class="list dir-left-wrap">
                <!-- 分销佣金 -->
                <view class="list-item">
                    <view @click="jump('/pages/share/money/money')">
                        <image :src="custom_setting.menus.money.icon"></image>
                        <view>{{custom_setting.menus.money.name}}</view>
                        <view>
                            <text>{{index.total_money?index.total_money:0}}</text>元
                        </view>
                    </view>
                </view>
                <!-- 分销订单 -->
                <view class="list-item">
                    <view @click="jump('/pages/share/order/order')">
                        <image :src="custom_setting.menus.order.icon"></image>
                        <view>{{custom_setting.menus.order.name}}</view>
                        <view>
                            <text>{{index.order_money?index.order_money:0}}</text>元
                        </view>
                    </view>
                </view>
                <!-- 提现明细 -->
                <view class="list-item">
                    <view @click="jump('/pages/share/cash-detail/cash-detail')">
                        <image :src="custom_setting.menus.cash.icon"></image>
                        <view>{{custom_setting.menus.cash.name}}</view>
                        <view>
                            <text>{{index.total_cash?index.total_cash:0}}</text>元
                        </view>
                    </view>
                </view>
                <!-- 我的团队 -->
                <view class="list-item">
                    <view @click="jump('/pages/share/team/team')">
                        <image :src="custom_setting.menus.team.icon"></image>
                        <view>{{custom_setting.menus.team.name}}</view>
                        <view>
                            <text>{{index.team_count?index.team_count:0}}</text>人
                        </view>
                    </view>
                </view>
                <!-- 推广二维码 -->
                <view class="list-item">
                    <view @click="jump('/pages/share/qrcode/qrcode')">
                        <image :src="custom_setting.menus.qrcode.icon"></image>
                        <view>{{custom_setting.menus.qrcode.name}}</view>
                    </view>
                </view>
                <!-- 团队分红 -->
                <view v-if="setting && setting.is_bonus == 1" class="list-item">
                    <view @click="jump('/plugins/bonus/index/index')">
                        <image src="./../image/img-bonus-price.png"></image>
                        <view>{{setting.form.entry_bonus?setting.form.entry_bonus:"团队分红"}}</view>
                    </view>
                </view>
                <!-- 股东分红 -->
                <view v-if="stock && stock.is_stock == 1" class="list-item">
                    <view @click="jump('/plugins/stock/index/index?name=' + share.name + '&mobile=' + share.mobile)">
                        <image src="./../image/img-stock-price.png"></image>
                        <view>{{stock.form.entry_bonus?stock.form.entry_bonus:"股东分红"}}</view>
                    </view>
                </view>
                <!-- 股东分红 -->
                <view v-if="region && region.is_region == 1" class="list-item">
                    <view @click="jump('/plugins/region/index/index?name=' + share.name + '&mobile=' + share.mobile)">
                        <image src="./../image/img-region-price.png"></image>
                        <view>{{region.form.entry_bonus?region.form.entry_bonus:"区域代理"}}</view>
                    </view>
                </view>
            </view>
        </view>
        <!-- 不是分销商 -->
        <view class="no-pass" v-else-if="status == 2 || apply">
            <image :src="share_setting.pic_url_status" class="add-bg"></image>
            <image src="./../image/success.png" class="success"></image>
            <view class="success-text">您已达到成为{{custom_setting.words.share_name.name ? custom_setting.words.share_name.name : custom_setting.words.share_name.default}}条件</view>
            <view v-if="becomeCondition == 'one_consume'">单次消费达到{{share_setting.auto_share_val}}元</view>
            <view v-if="becomeCondition == 'total_consume'">累计消费达到{{share_setting.total_consume}}元</view>
            <view v-if="becomeCondition == 'buy_goods'">购买{{share_setting.share_goods_status == 1 ? '任意商品' : share_setting.share_goods_status == 3 ? '指定分类' : '指定商品'}}</view>
            <view v-if="share_setting.share_condition == '2' || share_setting.share_condition == '4'" @click="jump('/pages/share/add/add?template_message=' + JSON.stringify(template_message))">
                <button :class="['no-pass-btn']">申请成为{{custom_setting.words.share_name.name ? custom_setting.words.share_name.name : custom_setting.words.share_name.default}}</button>
            </view>
            <view v-else @click="subscribe">
                <button :class="['no-pass-btn']">申请成为{{custom_setting.words.share_name.name ? custom_setting.words.share_name.name : custom_setting.words.share_name.default}}</button>
            </view>
            <view v-if="tabbarbool" class="bd-bottom-height-0"></view>
        </view>
        <view v-else-if="status == 0">
            <image :src="share_setting.pic_url_status" class="add-bg"></image>
            <view class="thx">
                <image src="./../image/img-share-info.png"></image>
                <view>谢谢您的支持，请等待审核</view>
            </view>
            <view @click="jump('/pages/index/index')">
                <view class="submit" style="margin:0">
                    <button >去商城逛逛</button>
                </view>
            </view>
            <view v-if="tabbarbool" class="bd-bottom-height-0"></view>
        </view>
        <view class="status-3 dir-top-nowrap" v-else-if="status == 3">
            <image :src="share_setting.pic_url_status" class="add-bg"></image>
            <view v-if="!showGoods && !showCats" class="apply-status-3">
                <view>分销商任务</view>
                <view class="status-3-tips">完成以下{{share_setting.new_become_condition.length > 1 ? '任一' : ''}}任务，可{{condition}}成为分销商</view>
                <view>
                    <view v-if="share_setting.new_become_condition.indexOf('one_consume') > -1" class="apply-item main-between cross-center">
                        <image src="./../image/target-ship.png"></image>
                        <view class="box-grow-1">
                            <view>单次消费<text>（{{order_price}}元/{{share_setting.auto_share_val}}元）</text></view>
                            <view class="progress">
                                <view :style="{'width':percent < 100 ? percent + '%' : '100%','min-width': percent > 0 ? '16rpx' : '0'}"></view>
                            </view>
                        </view>
                    </view>
                    <view v-if="share_setting.new_become_condition.indexOf('total_consume') > -1" class="apply-item main-between cross-center">
                        <image src="./../image/target-money.png"></image>
                        <view class="box-grow-1">
                            <view>累计消费<text>（{{total_order_price}}元/{{share_setting.total_consume}}元）</text></view>
                            <view class="progress">
                                <view :style="{'width':totalPercent < 100 ? totalPercent + '%' : '100%','min-width': totalPercent > 0 ? '16rpx' : '0'}"></view>
                            </view>
                        </view>
                    </view>
                    <view v-if="share_setting.new_become_condition.indexOf('buy_goods') > -1" class="apply-item main-between cross-center">
                        <image src="./../image/target-goods.png"></image>
                        <view class="box-grow-1">
                            <view>购买{{share_setting.share_goods_status == 1 ? '任意商品' : share_setting.share_goods_status == 3 ? '指定分类' : '指定商品'}}<text>（0/1）</text></view>
                            <view class="progress">
                                <view :style="{'width':0}"></view>
                            </view>
                        </view>
                        <view @click="toGoodsList" class="to-buy">去完成</view>
                    </view>
                </view>
            </view>
            <view v-if="showGoods || showCats" style="margin-top: -30rpx;">
                <app-goods-recommend :showBuyBtn="false" :showSales="true" :showUnderlinePrice="false" :onlyShowTitle="showCats" :comment-style="comment_style" :theme="getTheme" :goods-list="showGoods ?goods_list : []"></app-goods-recommend>
            </view>
            <view v-if="showCats" class="dir-left-wrap cat-list">
                <block v-for="(item, index) in cat_list" :key="index">
                    <view class="cat-item t-omit" @click="toGoods(item.value)">{{item.label}}</view>
                </block>
            </view>
            <view v-if="tabbarbool" class="bd-bottom-height-0"></view>
        </view>
        <view v-else-if="status == 4 || status == 5">
            <image :src="share_setting.pic_url_status" class="add-bg"></image>
            <view class="thx">
                <image class="warning" src="./../image/warning.png"></image>
                <template v-if="status == 4">
                    <view class="apply-status-4">您的申请被拒绝</view>
                    <view style="text-align: left">
                        <text style="color: #999;">审核时间：</text>
                        <text>{{share.apply_at}}</text>
                    </view>
                    <view style="text-align: left">
                        <text style="color: #999;">拒绝理由：</text>
                        <text>{{share.reason}}</text>
                    </view>
                </template>
                <template v-if="status == 5">
                    <view class="apply-status-4">您被解除{{custom_setting.words.share_name.name ? custom_setting.words.share_name.name : custom_setting.words.share_name.default}}身份</view>
                    <view style="text-align: left">
                        <text style="color: #999;">解除时间：</text>
                        <text>{{share.deleted_at}}</text>
                    </view>
                    <view style="text-align: left">
                        <text style="color: #999;">解除理由：</text>
                        <text>{{share.reason}}</text>
                    </view>
                </template>
            </view>
            <view @click="againApply" class="submit again-apply main-center" style="margin:0">
                <button>再次申请</button>
            </view>
            <view v-if="tabbarbool" class="bd-bottom-height-0"></view>
        </view>
        <view class="dir-top-nowrap cross-center disabled" v-else-if="status == 6">
            <image src="./../image/disabled.png" class="disabled-img"></image>
            <view class="disabled-text">当前功能未开放</view>
            <view class="disabled-btn" @click="jump('/pages/index/index')">去商城逛逛</view>
        </view>
    </app-layout>
</template>

<script>
    import { mapGetters, mapState } from "vuex";
    import appGoodsRecommend from "../../../components/page-component/app-goods-recommend/app-goods-recommend.vue";

    export default {
        components: {
            appGoodsRecommend
        },
        data() {
            return {
                showGoods: false,
                showCats: false,
                comment_style: {
                    pic_url: '../../../static/image/icon/icon-favorite.png',
                    text_color: '#999',
                    text: '指定商品',
                    list_style: 2
                },
                setting: null,
                status: -1,
                customize: [],
                name: null,
                becomeCondition: null,
                first: false,
                page_loading: true,
                inApply: false,
                apply: false,
                template_message: null,
                index: [],
                order_price: null,
                total_order_price: null,
                goods_list: null,
                cat_list: null,
                share: null,
                stock: null,
                region: null,
                is_can_apply: false,
                tabbarbool: false,
            }
        },
        computed: {
            ...mapState({
                userInfo: state => state.user.info,
                custom_setting: state => state.mallConfig.share_setting_custom,
                is_show_parent_name: state => state.mallConfig.mall.setting.is_show_parent_name,
                share_setting: state => state.mallConfig.share_setting,
                tabBarNavs: state => state.mallConfig.navbar.navs,
                mall: state => state.mallConfig.mall
            }),
            percent() {
                if (this.order_price === null) {
                    return 0;
                } else {
                    return parseFloat(this.order_price) / parseFloat(this.share_setting.auto_share_val) * 100;
                }
            },
            totalPercent() {
                if (this.total_order_price === null) {
                    return 0;
                } else {
                    // TODO 未完成
                    return parseFloat(this.total_order_price) / parseFloat(this.share_setting.total_consume) * 100;
                }
            },
            condition() {
                if (this.share_setting.share_condition == 5) {
                    return '自动';
                } else {
                    return '申请';
                }
            },
            ...mapGetters('mallConfig', {
                getTheme: 'getTheme'
            })
        },
        methods: {
            b() {
                let currentRoute = undefined;
                // #ifdef MP
                currentRoute = this.currentRoute;
                // #endif
                // #ifdef H5
                currentRoute = window.location.hash.split('#')[1].split('?')[0];
                // #endif
                for (let i = 0; i < this.tabBarNavs.length; i++) {
                    if(currentRoute.includes(this.tabBarNavs[i].url.split('?')[0])) {
                         this.tabbarbool = true;
                         return;
                    }
                }
                this.tabbarbool = false;
            },
            toGoodsList() {
                this.showGoods = false;
                this.showCats = false;
                if(this.share_setting.share_goods_status == 1) {
                    this.jump('/pages/index/index');
                }else if(this.share_setting.share_goods_status == 2) {
                    this.showGoods = true;
                    this.comment_style.text = '指定商品';
                }else if(this.share_setting.share_goods_status == 3) {
                    this.showCats = true;
                    this.comment_style.text = '指定分类';
                }
            },
            toApply() {
                this.apply = !this.apply;
            },
            jump(url) {
                uni.navigateTo({
                    url: url
                })
            },
            subscribe() {
                if (this.share_setting.share_condition == '2' || this.share_setting.share_condition == '2') {
                    if(this.apply){
                        this.apply = true;
                        return;
                    }
                }
                this.$subscribe(this.template_message).then(() => {
                    this.submit();
                }).catch(() => {
                    this.submit();
                });
            },
            submit() {
                let that = this;
                uni.showLoading({
                    title: '提交中...'
                });
                if(that.inApply) {
                    return false
                }
                that.inApply = true;
                that.$request({
                    url: that.$api.share.apply,
                    data: {
                        name: that.userInfo.nickname,
                        mobile: that.userInfo.mobile
                    },
                    method: 'post'
                }).then(response=>{
                    that.inApply = false;
                    uni.hideLoading();
                    if(response.code === 0) {
                        that.status = 0;
                        if (that.share_setting.share_condition == '3') {
                            that.status = 1;
                        }
                        that.apply = false;
                        that.getStatus();
                    }else {
                        uni.showToast({
                            title: response.msg,
                            icon: 'none',
                            duration: 1000
                        });
                    }
                }).catch(() => {
                    uni.hideLoading();
                });
            },
            getList() {
                let that = this;
                that.$request({
                    url: that.$api.share.index,
                }).then(response=>{
                    that.$hideLoading();
                    if(response.code === 0) {
                        that.index = response.data.list;
                        that.setting = response.data.bonus_setting.list;
                        that.stock = response.data.stock_setting;
                        that.region = response.data.region_setting;
                    }else {
                        uni.showToast({
                            title: response.msg,
                            icon: 'none',
                            duration: 1000
                        });
                    }
                }).catch(() => {
                    that.$hideLoading();
                });
            },
            getStatus() {
                let that = this;
                that.$request({
                    url: that.$api.share.new_apply_status,
                }).then(response=>{
                    that.first = true;
                    if(response.code === 0) {
                        that.becomeCondition = response.data.becomeCondition;
                        that.template_message = response.data.template_message;
                        that.status = response.data.status;
                        that.share = response.data.share;
                        that.order_price = response.data.orderPrice;
                        that.total_order_price = response.data.totalOrderPrice;
                        that.goods_list = response.data.goodsList;
                        that.cat_list = response.data.catList;
                        that.is_can_apply = response.data.is_can_apply;
                        if (that.status == 1) {
                            that.getList();
                            let name = response.data.share.name;
                            if (that.share_setting.share_condition == '3') {
                                name = that.userInfo.nickname
                            }
                            that.name = name;
                        } else if (that.status == 2) {
                            that.$hideLoading();
                            if (that.share_setting.share_condition != 2 && this.share_setting.share_condition != 4) {
                                that.apply = true;
                            }
                        }else {
                            that.$hideLoading();
                        }
                    }else {
                        that.$hideLoading();
                        uni.showModal({
                            content: response.msg,
                            showCancel: false
                        })
                    }
                }).catch(() => {
                    that.$hideLoading();
                    that.$event.on(that.$const.EVENT_USER_LOGIN).then(()=>{
                        that.$store.dispatch('user/info');
                        that.getStatus();
                    });
                });
            },
            againApply() {
                if (this.is_can_apply) {
                    if (this.share_setting.share_condition != 2 && this.share_setting.share_condition != 4) {
                        this.apply = true;
                    } else {
                        this.jump('/pages/share/add/add?template_message=' + JSON.stringify(this.template_message));
                    }
                } else {
                    this.status = 3;
                }
            },
            toGoods(cat_id) {
                this.$jump({
                    url: '/pages/goods/list?cat_id=' + cat_id,
                    open_type: 'navigate'
                });
            }
        },
        onLoad() { this.$commonLoad.onload();
            if (this.$user.isLogin()) {
                this.$store.dispatch('user/refreshInfo');
            }
            this.$showLoading({
                type: 'global',
                text: '加载中...'
            });
            this.getStatus();
            this.$nextTick(_ => {
                this.b();
            })
        },
        onShow() {
            let that = this;
            if(that.first) {
                that.getStatus();
            }
        }
    }
</script>

<style scoped lang="scss">
    .info {
        height: #{312rpx};
        background-color: #ff4544;
        width: 100%;
        padding: #{20rpx} #{25rpx} 0;
        color: #fff;
        font-size: #{28rpx};
        background-repeat: no-repeat;
        background-size: #{750rpx} #{312rpx};
    }
    .user-info {
        border-bottom: #{1rpx} solid #FFFFFF;
        padding-bottom: #{20rpx};
        .arrow-right {
            width: #{12rpx};
            height: #{22rpx};
            margin-left: #{12rpx};
            display: block;
        }
    }
    .user-avatar {
        width: #{120rpx};
        height: #{120rpx};
        border-radius: 50%;
        font-size: #{26rpx};
        margin-right: #{40rpx};
    }
    .user-name {
        font-size: #{36rpx};
    }
    .mtb-10 {
        margin: #{10rpx 0};
    }
    .share-info {
        float: left;
        margin-top: #{20rpx};
        font-size: #{28rpx};
    }
    .share-info text {
        font-size: #{46rpx};
    }
    .withdraw-btn {
        float: right;
        width: #{105rpx};
        border-radius: #{28rpx};
        height: #{56rpx};
        line-height: #{54rpx};
        font-size: #{28rpx};
        color: #fff;
        background-color: auto;
        text-align: center;
        border: #{2rpx} solid #fff;
        padding: 0;
        margin-top: #{48rpx};
    }
    .withdraw-btn::after {
        border: 0;
    }
    .nav {
        background-color: #fff;
        height: #{160rpx};
        padding: #{40rpx} 0;
        text-align: center;
        font-size: #{30rpx};
        color: #666;
        width: #{702rpx};
        margin: #{16rpx} auto 0;
        border-radius: #{10rpx};
    }
    .nav>view {
        width: 50%;
        text-align: center;
    }
    .nav-left {
        margin-left: #{-1rpx};
        border-right: #{1rpx} solid #bbb;
    }
    .nav-title {
        font-size: #{26rpx};
        color: #ff8f17;
        margin-bottom: #{10rpx};
    }
    .nav-left .nav-title {
        color: #22af19;
    }
    .list {
        margin: #{16rpx} auto 0;
        background-color: #fff;
        width: #{702rpx};
        border-radius: #{10rpx};
    }
    .list-item {
        height: #{220rpx};
        width: #{234rpx};
        text-align: center;
        padding-top: #{57rpx};
        font-size: #{24rpx};
        color: #666;
    }
    .list-item image {
        height: #{61rpx};
        width: #{61rpx};
        vertical-align: top;
        margin-top: #{-10rpx};
        margin-bottom: #{10rpx};
    }
    .list-item text {
        color: #ff6868;
    }
    .list-item.no-border {
        border-bottom: 0;
    }
    .no-pass {
        position: absolute;
        left: 0;
        right: 0;
        height: 100%;
        width: 100%;
        background-color: #fff;
        text-align: center;
        color: #999999;
        font-size: #{26rpx};
        .success-text {
            font-size: 32rpx;
            color: #333333;
            margin-bottom: 16rpx;
        }
        .success {
            width: 572rpx;
            height: 407.8rpx;
            margin: 97rpx auto 86rpx;
            display: block;
        }
    }
    .no-pass-btn {
        height: #{82rpx};
        width: #{454rpx};
        border-radius: #{41rpx};
        margin: #{74rpx} auto 0;
        color: #fff;
        font-size: #{34rpx};
        line-height: #{82rpx};
        background: #ff4544;
    }
    .withdraw-btn:active {
        background-color: rgba(0, 0, 0, 0.2);
    }
    .add-bg {
        height: #{300rpx};
        width: 100%;
        display: block;
        margin-bottom: #{20rpx};
        background-color: #f7f7f7;
    }
    .thx {
        padding: #{100rpx};
        text-align: center;
        color: #666;
        font-size: #{30rpx};
    }
    .thx image {
        height: #{80rpx};
        width: #{80rpx};
        margin-bottom: #{50rpx};
    }
    .submit {
        background-color: #f7f7f7;
        margin: 0 #{-24rpx};
        padding: #{24rpx};
    }
    .submit button {
        color: #fff;
        font-size: #{30rpx};
        font-weight: bold;
        height: #{100rpx};
        border-radius: #{50rpx};
        line-height: #{100rpx};
        background: #ff4544;
    }
    .bg {
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        background-color: rgba(0, 0, 0, .3);
        z-index: 10;
    }
    .dialog {
        position: fixed;
        top: #{400rpx};
        left: 0;
        right: 0;
        height: #{300rpx};
        width: #{640rpx};
        margin: 0 auto;
        z-index: 21;
        background-color: #fff;
        border-radius: 10px;
        text-align: center;
        font-size: #{30rpx};
    }
    .dialog-title {
        margin: #{40rpx} auto #{35rpx};
    }
    .dialog-btn {
        height: #{88rpx};
        width: #{640rpx};
        border-top: #{1rpx} solid #e2e2e2;
        line-height: #{88rpx};
        position: absolute;
        bottom: 0;
        left: 0;
    }
    .dialog-close,.dialog-submit {
        width: 50%;
    }
    .line {
        height: #{44rpx};
        margin-top: #{22rpx};
        width: #{1rpx};
        background-color: #e2e2e2;
    }
    .dialog-submit {
        color: #ff4544;
    }
    .apply-status-4 {
        border-bottom: #{1rpx solid #e2e2e2};
        padding-bottom: #{32rpx};
        margin-bottom: #{32rpx};
        font-size: $uni-font-size-import-one;
        color: #353535;
    }
    .thx image.warning {
        width: #{160rpx};
        height: #{160rpx};
    }
    .again-apply {
        button {
            width: #{320rpx};
        }
    }
    .status-3 {
        background-color: #F6F6F6;
        min-height: 100vh;
        font-size: 32rpx;
        color: #333333;
        .apply-status-3 {
            padding: 0 30rpx;
            .status-3-tips {
                font-size: 26rpx;
                color: #999999;
                margin: 10rpx 0 30rpx;
            }
            .apply-item {
                padding: 0 24rpx;
                margin: 20rpx 0 0;
                width: 690rpx;
                height: 132rpx;
                background: #FFFFFF;
                border-radius: 20rpx;
                font-size: 26rpx;
                color: #333333;
                .to-buy {
                    width: 118rpx;
                    height: 52rpx;
                    background: #FFFFFF;
                    border: 2rpx solid #FF4544;
                    text-align: center;
                    line-height: 48rpx;
                    border-radius: 26rpx;
                    margin-left: 22rpx;
                    color: #FF4544;
                }
                image {
                    width: 76rpx;
                    height: 76rpx;
                    margin-right: 14rpx;
                }
                text {
                    font-size: 24rpx;
                    color: #999999;
                }
                .progress {
                    margin-top: 18rpx;
                    border-radius: 8rpx;
                    position: relative;
                    width: 100%;
                    height: 16rpx;
                    background: #FFECEC;
                    >view {
                        position: absolute;
                        left: 0;
                        top: 0;
                        min-width: 16rpx;
                        border-radius: 8rpx;
                        height: 16rpx;
                        background: #FF4544;
                    }
                }
            }
        }
    }
    .share-goods-status-1 {
        .content {
            text-align: center;
            color: #353535;
            font-size: #{35rpx};
            margin-top: #{60rpx};
            margin-bottom: #{80rpx};
            text {
                color: #ff4544;
                font-size: #{45rpx};
            }
        }
        .goods-list {
            background-color: #f7f7f7;
            padding-bottom: 0;
            padding-bottom: constant(safe-area-inset-bottom);
            padding-bottom: env(safe-area-inset-bottom);
        }
        .goods-title {
            color: #a6a6a6;
            margin-top: #{36rpx};
            margin-bottom: #{34rpx};
            .border {
                width: #{40rpx};
                border: #{1rpx solid #a6a6a6};
                &:first-child {
                    margin-right: #{24rpx};
                }
                &:last-child {
                    margin-left: #{24rpx};
                }
            }
            image {
                width: #{24rpx};
                height: #{24rpx};
                display: block;
                margin-right: #{12rpx};
            }
        }
    }

    .cat-list {
        padding: #{0 24rpx};
        .cat-item {
            width: #{221rpx};
            padding: #{10rpx 27rpx};
            font-size: $uni-font-size-general-one;
            border-radius: #{30rpx};
            border: #{2rpx solid #e2e2e2};
            background-color: #ffffff;
            margin-right: #{18rpx};
            margin-bottom: #{34rpx};
            text-align: center;
        }
    }

    .disabled {
        padding-top: #{156rpx};

        .disabled-img {
            width: #{240rpx};
            height: #{237rpx};
            display: block;
        }

        .disabled-text {
            font-size: $uni-font-size-general-two;
            color: #999999;
            margin-top: #{62rpx};
        }

        .disabled-btn {
            margin-top: #{80rpx};
            width: #{320rpx};
            height: #{80rpx};
            font-size: $uni-font-size-import-two;
            color: #ffffff;
            background: #ff4544;
            border-radius: #{40rpx};
            text-align: center;
            line-height: #{80rpx};
        }
    }
    .bd-bottom-height-0 {
        width:100%;
        height: 110upx;
    }
</style>
