export default {
    data() {
        return {
            calcError: false,
            data: null,
            ErrorMsg: '',
            origin: '',//form-button
        }
    },

    methods: {
        bolan(str) {
            function handleCalculation(numArr, num1, num2, char) {
                if (char == '+') {
                    numArr.push(num1 + num2);
                } else if (char == '-') {
                    numArr.push(num1 - num2);
                } else if (char == '*') {
                    numArr.push(num1 * num2);
                } else if (char == '/') {
                    numArr.push(num1 / num2);
                }
            }

            function isPop(char1, char2) {
                if ((char1 == '+' || char1 == '-') && (char2 == '+' || char2 == '-')) return true;
                if ((char1 == '+' || char1 == '-') && (char2 == '*' || char2 == '/')) return true;
                if ((char1 == '*' || char1 == '/') && (char2 == '*' || char2 == '/')) return true;
                if ((char1 == '*' || char1 == '/') && (char2 == '+' || char2 == '-')) return false;
            }

            // 分割字符串
            let arr = [];
            for (let i = 0; i < str.length; i++) {
                let t = str.charAt(i);
                let v = t;
                if (/[\d|\.]/.test(t + '')) {
                    let j = i;
                    for (; j < str.length; j++) {
                        let m = str.charAt(j);
                        if (!/[\d|\.]/.test(m + '')) {
                            break;
                        }
                    }
                    v = str.slice(i, j);
                    if (j > i) {
                        i = j - 1;
                    }
                    v = +v;
                }
                arr.push(v)
            }

            let numArr = [], charArr = [];
            for (let i = 0; i < arr.length; i++) {
                if (typeof arr[i] == 'number') {
                    numArr.push(arr[i])
                } else {
                    if (charArr.length) {
                        while (isPop(arr[i], charArr[charArr.length - 1])) {
                            let t2 = numArr.pop();
                            let t1 = numArr.pop();
                            let char = charArr.pop();
                            handleCalculation(numArr, t1, t2, char);
                        }
                        if (arr[i] == ')') {
                            let st = charArr[charArr.length - 1];
                            while (st != '(') {
                                let t1, t2;
                                let char = charArr.pop();
                                if (char != '(') {
                                    t2 = numArr.pop();
                                    t1 = numArr.pop();
                                }
                                handleCalculation(numArr, t1, t2, char);
                                st = char;
                            }
                        }
                        if (arr[i] != ')') {
                            charArr.push(arr[i])
                        }
                    } else {
                        charArr.push(arr[i])
                    }
                }
            }
            while (charArr.length) {
                let t2 = numArr.pop();
                let t1 = numArr.pop();
                let char = charArr.pop();
                handleCalculation(numArr, t1, t2, char);
            }
            return numArr.shift();
        },
        handlerCalcPrice() {
            if (!this.data || !this.goodsForm || !this.goodsForm.otherForm) {
                return ''
            }

            const {calc = []} = this.data,
                {otherForm, formList, hideIds, hideIdsStatus, options} = this.goodsForm,
                realHideIds = [].concat(hideIds, hideIdsStatus),
                {origin} = this;

            let str = '';
            for (let {type, ignore, label, id} of calc) {
                let value = '';
                if (type === 'operation') {
                    value = ignore === 'add' ? '+' : value;
                    value = ignore === 'sub' ? '-' : value;
                    value = ignore === 'multiply' ? '*' : value;
                    value = ignore === 'except' ? '/' : value;
                    value = ignore === 'bracket-left' ? '(' : value;
                    value = ignore === 'bracket-right' ? ')' : value;
                }
                if (type === 'const') {
                    value = label;
                }
                if (type === 'variable') {
                    for (let j of otherForm) {
                        const {unique, key} = j
                        if (ignore === unique) {
                            if (key === 'number-in') {
                                if (realHideIds.indexOf(unique) === -1) {
                                    n = j.value
                                } else {
                                    n = formList.filter(_ => _.data.key === unique).map(_ => _.data.default_var)
                                }
                                let n
                                value = n || 0
                            } else if (key === 'calc') {
                                value = j.value || 0;
                            } else if (key === 'radio') {
                                let v = [];
                                for (let _ of formList) {
                                    if (_.data.key === unique) {
                                        if ( _.value) {
                                            v = _.data.list.filter(__ => __.label == j.value).map(_ => _.var);
                                        }
                                        v = v.length > 0 ? v.shift() : _.data.default_var;
                                        break;
                                    }
                                }
                                value = v || 0;
                            } else if (key === 'select') {
                                let v = [];
                                for (let _ of formList) {
                                    if (_.data.key === unique) {
                                        if (_.value && _.value.length) {
                                            v = _.data.list.filter(__ => _.value.indexOf(__.label) !== -1).map(_ => _.var);
                                        }
                                        v = v.length == 0 ? [_.data.default_var] : v;
                                    }
                                }
                                value = v.reduce((a, b) => Number(a) + Number(b), 0);
                            }
                        }
                    }
                    const {price, stock} = options;
                    if (ignore === 'goods-price') {
                        value = price * stock || 0
                    }
                    if (ignore === 'alone-price') {
                        value = price;
                    }
                    if (ignore === 'alone-num') {
                        value = stock;
                    }
                }

                if (value === '') {
                    console.log({type, ignore, label, id}, `${origin}参数空`);
                    return;
                } else {
                    str += value;
                }
            }
            if (calc.length === 0) {
                if (origin === 'form-button') {
                    const {price, stock} = options
                    str = price + '*' + stock
                }
                if (origin === 'calc') {
                }
            }

            try {
                this.ErrorMsg = '数据填写有误，请重新填写后提交';
                console.log(`(${origin}) calc =>`, str);
                let r = this.bolan(str);
                if (r === Infinity || r < 0 || r == null || isNaN(r)) throw new Error("Infinity");
                this.calcError = false;
                if (r > 99999999.99) {
                    this.ErrorMsg = '数值超过1亿  请核对数据';
                    throw new Error('MAX');
                }
                return Number(r.toString().match(/^\d+(?:\.\d{0,2})?/))
            } catch (e) {
                this.calcError = true;
                console.error(`${origin}计算不合法`)
                return '计算不合法'
            }
        }
    },
    inject: ['goodsForm'],
}
