<template>
    <app-layout>
	    <app-phone-binding :bind="bind" @click="bindPhone" :phone="phone"></app-phone-binding>
    </app-layout>
</template>

<script>
	import appPhoneBinding from './app-phone-binding/app-phone-binding.vue';
	
    export default {
        name: "binding",
	    data() {
            return {
                bind: false,
                phone: ''
            }
	    },
	    onLoad() { this.$commonLoad.onload();
            this.$request({
	            url: this.$api.user.user_info,
            }).then(response => {
                if (response.code === 0) {
                    if (response.data.mobile !== '') {
                        this.bind = true;
						// #ifdef MP-ALIPAY
                        let first = response.data.mobile.substring(0,3);
                        let last = response.data.mobile.substring(response.data.mobile.length-2);
                        this.phone = first+ '***' + last;
						// #endif
						// #ifndef MP-ALIPAY
                        this.phone = response.data.mobile;
						// #endif
                    }
                }
            })
	    },
	    methods: {
            bindPhone(data) {
                this.bind = data;
            }
	    },
        components: {
            'app-phone-binding': appPhoneBinding,
        }
    }
</script>
