<template>
    <view class="product-list">
        <view class="item dir-left-nowrap" v-for="(item, key) in goods_list" :key="key" @click="route_go(item)">
            <view class="box-grow-0 cover-pic">
                <image class="pic" :src="item.cover_pic"></image>
                <view class="out-dialog" v-if="item.goods_stock == 0 && appSetting.is_show_stock == '1'">
                    <image mode="aspectFill" :src="appSetting.is_use_stock == '1' ? appImg.plugins_out : appSetting.sell_out_pic"></image>
                </view>
            </view>
            <view class="box-grow-1 dir-top-nowrap main-between">
                <view class="box-grow-1">
                    <text class="name t-omit">{{item.name}}</text>
                    <view class="main-between cross-center">
                        <view class="sales">{{item.sales}}</view>
                        <app-sup-vip class="margin-vip" :is_vip_card_user="item.vip_card_appoint.is_vip_card_user"
                                     v-if="item.vip_card_appoint && item.vip_card_appoint.discount"
                                     :discount="item.vip_card_appoint && item.vip_card_appoint.discount">
                        </app-sup-vip>
                    </view>
                </view>
                <view class="price-but dir-left-nowrap main-between cross-center">
                    <view class="box-grow-1" style="width: 100%;">
                        <view class="app-min-price" :style="{'color': theme.color}">
                            <text class="price-float" v-if="item.priceList.priceInt > 0 || item.priceList.priceInt == 0">￥</text>
                            <text class="price-int" :class="item.priceList.priceInt > 0 || item.priceList.priceInt == 0 ? '' :'text'">{{item.priceList.priceInt}}</text>
                            <text class="price-float">{{item.priceList.priceFloat}}</text>
                        </view>
                        <view v-if="item.is_level && (item.level_price > 0 || item.level_price == 0) && item.is_negotiable != 1" class="app-member-price" :style="{'background':theme.background_p,'color':theme.color}">
                            <text class="t-omit">会员价
                                <text class="price-float">￥</text>
                                <text class="price-int">{{item.memberList.priceInt}}</text>
                                <text v-if="item.memberList.priceFloat != '.00'" class="price-float">{{item.memberList.priceFloat}}</text>
                            </text>
                        </view>
                        <view v-else-if="isListUnderlinePrice && item.is_negotiable != 1" class="app-original-price">￥{{item.original_price}}</view>
                    </view>
                    <view v-if="item.is_negotiable != 1 && isShowCart == 1 && item.goods_stock > 0" class="box-grow-0 cart-box">
                        <view class="goods-cart"  @click.stop.native="specification(item)">
                            <cats-image :theme="theme" ></cats-image>
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
    import {mapGetters, mapState} from 'vuex';
    import catsImage from './cats-image.vue';

    export default {
        name: "product-list",
        props : [`goods_list`, `theme`],
        components: {
            catsImage
        },
        data() {
            return {
                previewUrl: '',
                submitUrl: '',
                attrGroup: [],
                selectAttr: {},
                item: {},
                show: 0
            }
        },
        computed: {
            ...mapGetters('mallConfig', {
                getVideo: 'getVideo'
            }),
            ...mapState({
                appSetting: state => state.mallConfig.mall.setting,
                appImg: state => state.mallConfig.__wxapp_img.mall,
                isShowCart: state => state.mallConfig.mall.setting.is_show_cart,
                isListUnderlinePrice: state => state.mallConfig.mall.setting.is_list_underline_price,
                platform: function(state) {
                    return state.gConfig.systemInfo.platform;
                }
            })
        },
        methods: {
            specification(goods) {
                if (goods.sign === 'mch') {
                    this.previewUrl = this.$api.mch.order_preview;
                    this.submitUrl = this.$api.mch.order_submit;
                } else {
                    this.previewUrl = '';
                    this.submitUrl = '';
                }
                uni.showLoading({
                    text: '',
                    mask: true
                });
                this.$request({
                    url: this.$api.goods.attr,
                    data: {
                        id: goods.id,
                        mch_id: goods.mch_id
                    }
                }).then(e => {
                    uni.hideLoading();
                    if (e.code === 0) {
                        let data = Object.assign(goods, e.data);
                        this.$emit('attr', {
                            previewUrl: this.previewUrl, submitUrl: this.submitUrl, attr_groups: goods.attr_groups, goods: data
                        });
                    } else {
                        uni.showToast({
                            title: e.msg,
                            icon: 'none'
                        })
                    }
                })
            },
            route_go(item) {
                // #ifndef MP-BAIDU
                if (item.video_url && this.getVideo == 1) {
                    // #ifdef MP
                    uni.navigateTo({
                        url: `/pages/goods/video?goods_id=${item.id}&sign=${item.sign}`
                    });
                    // #endif
                    // #ifdef H5
                    uni.navigateTo({
                        url: item.page_url
                    });
                    // #endif
                } else {
                    uni.navigateTo({
                        url: item.page_url
                    });
                }
                // #endif

                // #ifdef MP-BAIDU
                uni.navigateTo({
                    url: item.page_url
                });
                // #endif
            },
            onAttr(data) {
                this.selectAttr = data;
            }
        }
    }
</script>

<style scoped lang="scss">

    .cover-pic {
        position: relative;
        border-radius: #{8upx};
        margin-right: #{20upx};
        flex-shrink: 0;
    }
    .out-dialog {
        width: #{200upx};
        height: #{200upx};
        position: absolute;
        top: 0;
        left: 0;
        z-index: 10;
        background-color: rgba(0,0,0,.5);
        image {
            width: #{200upx};
            height: #{200upx};
        }
    }
    .item {
        width: #{504upx};
        border-bottom: #{1upx} solid #e2e2e2;
        margin: #{20upx 0 0 0};
        padding-bottom: #{20upx};
    }
    .product-list > .item:last-child {
        border-bottom-width: 0 !important;
    }
    .cover-pic {
        width: #{200upx};
        height: #{200upx};

        border-radius: #{8upx};
        margin-right: #{20upx};
        position: relative;
    }
    .pic {
        width: #{200upx};
        height: #{200upx};
    }
    .name {
        font-size: 28upx;
        line-height: 38upx;
        color: #353535;
        white-space: inherit;
        margin-top: #{5upx};
    }
    .margin-vip {
        margin: #{8upx 0 0 0};
    }
    .price-but {
        margin-top: #{8upx};
        .app-min-price {
            font-family: Alibaba;
            font-size: #{40rpx};
            margin-top: 10rpx;
            line-height: 1;
            margin-right: 14rpx;
            .text {
                font-size: 34rpx;
            }
            .price-float {
                font-size: 28rpx;
            }
        }
        .app-member-price {
            font-size: 24rpx;
            padding: 0 6rpx;
            overflow: hidden;
            white-space: nowrap;
            display: inline-block;
        }
        .app-original-price {
            font-size: #{24rpx};
            color: #999999;
            text-decoration: line-through;
            line-height: 1;
        }
    }
    .price_content {
        font-size: #{28upx};
        line-height: 1;
        text-align: left;
        font-family: Alibaba;
    }
    .cart-box {
        width:#{56rpx};
        height:#{56rpx};
        border-radius: 50%;
        position: relative;
        overflow: hidden;
        transform: rotateZ(360deg);
    }
    .sales {
        font-size: #{20upx};
        line-height: 1;
        color: #999999;
        margin-top: #{5upx};
        padding-left: #{5upx};
    }
    .goods-cart {
        width:#{56rpx};
        height:#{56rpx};
        /*position: absolute;*/
        /*top: 50%;*/
        /*left: 50%;*/
        border:none;

    }

    .origin-price {
        font-size: 21upx;
        color: #999999;
        text-decoration:line-through;
    }
</style>