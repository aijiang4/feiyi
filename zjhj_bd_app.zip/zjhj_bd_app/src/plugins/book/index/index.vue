<template>
    <app-layout>
        <view class="book-index">
            <view class="page-width head-nav-list dir-left-nowrap cross-center" v-if="is_show_cat === 1">
                <view class="app-search">
                    <app-jump-button form open_type="navigate" url="/pages/search/search?sign=book">
                        <view class="app-icon"></view>
                    </app-jump-button>
                </view>
                <view class="app-line"></view>
                <app-head-nav-list
                    v-bind:catList="catList"
                    @click="changeStatus"
                    v-bind:cat_id="cat_id"
                    :theme="getTheme"
                ></app-head-nav-list>
            </view>

            <view class="page-width goods-list main-between" :class="is_show_cat === 1 ? 'product-list' : ''" v-if="goods_list.length > 0">
<!--                 <app-product-list :theme="getTheme" v-bind:goodsList="goods_list"
                                  @route_go="route_go"></app-product-list> -->
                <!-- <view v-for="(item,index) in goods_list" :key="index" class="dir-left-wrap"> -->
                    <app-goods
                      v-for="(goods,idx) in goods_list" :key="goods.goods_id"
                      :showTag="false"
                      :listStyle="2"
                      :index="idx"
                      :theme="getTheme"
                      :goods="goods"
                      buyBtnText="预约"
                      :c_border_top="16"
                      :c_border_bottom="16"
                      :padding="24"
                    ></app-goods>
                <!-- </view> -->
            </view>
            <view class="page-width no-goods" v-else-if="is_load">
                <app-no-goods background="#f7f7f7"></app-no-goods>
            </view>
        </view>
    </app-layout>
</template>

<script>
import appHeadNavList from '../components/app-head-nav-list.vue';
import appProductList from '../components/app-product-list.vue';
import appNoGoods from '../../../components/page-component/app-no-goods/app-no-goods.vue';
import appGoods from '../../../components/basic-component/app-goods/app-goods.vue';
import {mapGetters, mapState} from "vuex";

export default {
    name: "index",

    data() {
        return {
            catList: [],
            cat_id: 0,
            page: 1,
            goods_list: [],
            page_count: 1,
            is_load: false,
            is_show_cat: 0,
            text: '123123123'
        }
    },
    onLoad(option) { this.$commonLoad.onload(option);
        // #ifdef H5
        if (!this.$jwx.isWechat()) {
            uni.getLocation({
                success: function () {
                },
                fail: function () {
                    window.location.reload();
                },
            });
        }
        // #endif
        this.requestCats().then(() => {
            if (option.cat_id) {
                this.cat_id = option.cat_id;
            } else {
                this.cat_id = this.catList[0].id;
            }
            this.requestList();
        });
        // #ifdef MP-WEIXIN
        wx.showShareMenu({
            menus: ['shareAppMessage', 'shareTimeline']
        })
        // #endif
    },
    methods: {
        async requestCats() {
            this.$showLoading();
            const e = await this.$request({
                url: this.$api.book.cats,
                method: 'get'
            });
            if (e.code === 0) {
                this.catList = e.data.cat;
                this.is_show_cat = e.data.is_show_cat;
            }
        },

        async requestList(status) {
            const res = await this.$request({
                url: this.$api.book.list,
                data: {
                    page: this.page,
                    cat_id: this.cat_id,
                }
            });
            this.$hideLoading();
            if (res.code === 0) {
                this.is_load = true;
                if (status) this.goods_list = [];
                this.dataProcessing(res.data);
            }
        },

        changeStatus(status) {
            this.page = 1;
            this.cat_id = status;
            this.requestList(true);
        },

        dataProcessing(data) {
            for (let i = 0; i < data.list.length; i ++) {
                this.goods_list.push(data.list[i]);
            }
            this.page_count = data.pagination.page_count;
        },

        route_go(data) {
            let _this = this;
            // #ifndef MP-BAIDU
            if (data.video_url && this.getVideo == 1) {
                // #ifdef MP
                uni.navigateTo({
                    url: `/pages/goods/video?goods_id=${data.goods_id}&sign=booking`
                });
                // #endif

                // #ifdef H5
                if (this.$jwx.isWechat()) {
                    this.$jwx.getLocation({
                        success: function() {
                            uni.navigateTo({
                                url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                            });
                        },
                        fail: function() {
                            uni.showToast({
                                title: '请开启位置权限',
                                icon: 'none',
                                duration: 1000,
                                success: function () {

                                }
                            });
                        }
                    })
                } else {
                    uni.getLocation({
                        type: 'wgs84',
                        success: function () {
                            uni.navigateTo({
                                url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                            });
                        },
                        fail: function (res) {
                            uni.showToast({
                                title: '请开启位置权限',
                                icon: 'none',
                                duration: 1000,
                                success: function () {

                                }
                            });
                        },
                    });
                }
                // #endif


            } else {
                // #ifndef H5
                uni.getLocation({
                    type: 'wgs84',
                    success: function () {
                        uni.navigateTo({
                            url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                        });
                    },
                    fail: function () {
                        uni.showToast({
                            title: '请开启位置权限',
                            icon: 'none',
                            duration: 1000,
                            success: function () {

                            }
                        });
                    },
                });
                // #endif

                // #ifdef H5
                if (this.$jwx.isWechat()) {
                    this.$jwx.getLocation({
                        success: function() {
                            uni.navigateTo({
                                url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                            });
                        },
                        fail: function() {
                            uni.showToast({
                                title: '请开启位置权限',
                                icon: 'none',
                                duration: 1000,
                                success: function () {

                                }
                            });
                        }
                    })
                } else {
                    uni.navigateTo({
                        url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                    });
                    // uni.getLocation({
                    //     success: function () {
                    //         uni.navigateTo({
                    //             url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                    //         });
                    //     },
                    //     fail: function () {
                    //         uni.showModal({
                    //             title: '提示',
                    //             content: '定位失败，确保定位服务已开启',
                    //             success: function (res) {
                    //                 if (res.confirm) {
                    //                     window.location.reload();
                    //                 } else if (res.cancel) {
                    //                     let pages = getCurrentPages();
                    //                     if (pages.length > 1) {
                    //                         uni.navigateBack();
                    //                     } else {
                    //                         uni.navigateTo({
                    //                             url: 'pages/index/index'
                    //                         });
                    //                     }
                    //                 }
                    //             }
                    //         });
                    //     },
                    // });
                }
                // #endif
            }
            // #endif

            // #ifdef MP-BAIDU
            uni.getLocation({
                type: 'wgs84',
                success: function () {
                    uni.navigateTo({
                        url: `/plugins/book/goods/goods?goods_id=${data.goods_id}`,
                    });
                },
                fail: function () {
                    uni.showToast({
                        title: '请开启位置权限',
                        icon: 'none',
                        duration: 1000,
                        success: function () {

                        }
                    });
                },
            });
            // #endif

        }
    },
    onReachBottom() {
        if (this.page < this.page_count) {
            this.page++;
            this.requestList();
        }
    },
    computed: {
        ...mapGetters('mallConfig', {
            getTheme: 'getTheme',
        }),
        ...mapState({
            platform: function(state) {
                return state.gConfig.systemInfo.platform;
            }
        })
    },
    // #ifdef MP
    onShareAppMessage() {
        return this.$shareAppMessage({
            path: '/plugins/book/index/index',
            title: this.$children[0].navigationBarTitle,
        });
    },
    // #endif
    // #ifdef MP-WEIXIN
    onShareTimeline() {
        // 分享朋友圈beta
        return this.$shareTimeline({
            title: this.$children[0].navigationBarTitle,
            query: {} // 此处填写页面的参数
        });
    },
    // #endif
    components: {
        'app-head-nav-list': appHeadNavList,
        'app-product-list': appProductList,
        'app-no-goods': appNoGoods,
        appGoods
    },
}
</script>

<style scoped lang="scss">

.head-nav-list {
    position: fixed;
    top: 0;
    left: 0;
    background-color: #fff;
    z-index: 1500;
    .app-search {
        width: #{108rpx};
        height: #{92rpx};
        flex-shrink: 0;
        .app-icon {
            width: #{60rpx};
            height: #{60rpx};
            background-image: url("../image/big-sarch.png");
            background-size: 100% 100%;
            background-repeat: no-repeat;
        }
    }
    .app-line {
        width: #{1rpx};
        height: #{40rpx};
        background-color: #e2e2e2;
        flex-shrink: 0;
    }
}
.goods-list {
    flex-wrap: wrap;
    padding: 0 #{24rpx};
}
.product-list {
    margin-top: #{100rpx};
}

.no-goods {
    margin-top: #{150rpx};
}
</style>
