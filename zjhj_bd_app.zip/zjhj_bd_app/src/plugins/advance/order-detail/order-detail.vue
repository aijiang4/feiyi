<template>
	<view class="order-detail"></view>
</template>

<script>
    export default {
        name: "order-detail"
    }
</script>

<style scoped lang="scss">
	.order-detail {
		position: absolute;
		width: #{750rpx};
		height: 100%;
	}
</style>