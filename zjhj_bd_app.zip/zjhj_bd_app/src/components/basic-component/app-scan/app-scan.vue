<template>
	<view @click="scanCode" class="app-scan main-center cross-center">
		<image src="/static/image/icon/scan.png"></image>
	</view>
</template>

<script>
    export default {
        name: "app-scan",
	    
	    props: {
	    },
	    methods: {
            scanCode() {
                let that = this;
                uni.scanCode({
                    success(res) {
                    	console.log(res)
                    	if(res.result) {
                        	that.$emit('get', res.result)
                    	}
                    },
                    fail(res) {
                    	if(res.result) {
                        	that.$emit('get', res.result)
                    	}
                    }
                })
                // #ifdef H5
                if (that.$jwx.isWechat()) {
                    that.$jwx.scanQRCode({
                        success(res) {
                            if(res.resultStr) {
                                if(res.resultStr.indexOf(',') > 0){     
                                     var dealserialNumber=res.resultStr.split(',')[1];          
                                     dealserialNumber = dealserialNumber.replace(/[^a-z\d]/ig, "");//处理条形码扫描的字符
                                     that.$emit('get', dealserialNumber)
                                }
                            }else if(res.result) {
                                that.$emit('get', res.result)
                            }
                        }
                    })
                }
                // #endif
            },
	    }
    }
</script>

<style scoped lang="scss">
	.app-scan {
		height: 100%;
		width: 49rpx;
		image {
			width: 29rpx;
			height: 29rpx;
		}
	}
</style>