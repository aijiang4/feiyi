<template>
    <view class="app-composition dir-left-nowrap">
        <view @click.stop="open">
            <view class="app-composition-goods" :class="item.goods_list.length == 2 ? 'two' : item.goods_list.length == 3 ? 'three' : item.goods_list.length == 4 ? 'four': 'five'" v-if="item.type == 1">
                <image mode="aspectFill" :src="goods.cover_pic" v-for="goods in item.goods_list" :key="goods.id"></image>
            </view>
            <view class="app-composition-goods" :class="item.goods_list.length == 1 ? 'two' : item.goods_list.length == 2 ? 'three' : item.goods_list.length == 3 ? 'four': 'five'" v-if="item.type == 2">
                <image mode="aspectFill" :src="goods.cover_pic" v-for="goods in item.host_list" :key="goods.id"></image>
                <image mode="aspectFill" :src="goods.cover_pic" v-for="goods in item.goods_list" :key="goods.id"></image>
            </view>
            <slot></slot>
        </view>
        <view @click.stop="toDetail" class="app-composition-right box-grow-1" :class="large ? 'dir-top-nowrap main-between' : ''">
            <view class="dir-left-nowrap app-composition-info" :class="large ? 't-omit-two' :  't-omit'">
                <text class="app-composition-type large" v-if="item.type == 1 && large" :style="{'background':theme.background}">固定套餐</text>
                <text class="app-composition-type large" v-if="item.type == 2 && large" :style="{'background':theme.background}">搭配套餐</text>
                <text class="app-composition-type" v-if="item.type == 1 && !large" :style="{'color':theme.color}">固定</text>
                <text class="app-composition-type" v-if="item.type == 2 && !large" :style="{'color':theme.color}">搭配</text>
                <text class="app-composition-name" :class="large ? 'long-name' :  ''">{{item.name}}</text>
            </view>
            <div>
                <view class="app-composition-price" :style="{'color':theme.color}">
                    套餐价：
                    <text v-if="large">￥</text>
                    <text v-if="large" class="price-int">{{price.priceInt}}</text>
                    <text v-if="large">{{price.priceFloat}}</text>
                    <text v-else>￥{{item.min_composition_price}}</text>
                </view>
                <view class="app-composition-discount">
                    最多可省<text>￥{{item.max_discount}}</text>
                </view>
            </div>
        </view>
    </view>
</template>

<script>

	import {mapState} from 'vuex';
	
    export default {
        name: "app-composition",
	    props: {
            item: {
                type: Object
            },
            large: Boolean,
            theme: Object
	    },
        data() {
            return {
                price: {
                    priceFloat: '',
                    priceInt: '',
                },
            }
        },
        created() {
            let that = this;
            that.price = that.handlePrice(that.item.min_composition_price);
        },
        methods: {
            open(e) {
                this.$emit('click', e);
            },
            toDetail(e) {
                this.$emit('look', e);
            }
        }
    }
</script>

<style scoped lang="scss">
    .app-composition {
        .app-composition-goods {
            width: #{288rpx};
            height: #{140rpx};
            flex-shrink: 0;
            margin-right: #{24rpx};
            position: relative;
            &.two {
                image {
                    position: absolute;
                    width: #{140rpx};
                    height: #{140rpx};
                    border-radius: #{8rpx};
                    top: 0;
                }
                image:first-of-type {
                    left: 0;
                }
                image:last-of-type {
                    right: 0;
                }
            }
            &.three {
                image {
                    position: absolute;
                    width: #{140rpx};
                    height: #{66rpx};
                    border-radius: #{8rpx};
                }
                image:first-of-type {
                    left: 0;
                    top: 0;
                    height: #{140rpx};
                    width: #{140rpx};
                }
                image:nth-child(2) {
                    top: 0;
                    right: 0;
                }
                image:last-of-type {
                    bottom: 0;
                    right: 0;
                }
            }
            &.four {
                image {
                    position: absolute;
                    width: #{66rpx};
                    height: #{66rpx};
                    border-radius: #{8rpx};
                }
                image:first-of-type {
                    left: 0;
                    top: 0;
                    height: #{140rpx};
                    width: #{140rpx};
                }
                image:nth-child(2) {
                    top: 0;
                    right: 0;
                    width: #{140rpx};
                }
                image:nth-child(3) {
                    right: #{74rpx};
                    bottom: 0;
                }
                image:last-of-type {
                    right: 0;
                    bottom: 0;
                }
            }
            &.five {
                image {
                    position: absolute;
                    width: #{66rpx};
                    height: #{66rpx};
                    border-radius: #{8rpx};
                }
                image:first-of-type {
                    left: 0;
                    top: 0;
                    height: #{140rpx};
                    width: #{140rpx};
                }
                image:nth-child(2) {
                    top: 0;
                    right: #{74rpx};
                }
                image:nth-child(3) {
                    right: 0;
                    top: 0;
                }
                image:nth-child(4) {
                    right: #{74rpx};
                    bottom: 0;
                }
                image:last-of-type {
                    right: 0;
                    bottom: 0;
                }
            }
        }
        .app-composition-right {
            width: #{342rpx};
            text-align: left;
        }
        .app-composition-info {
            width: #{342rpx};
            .app-composition-type {
                font-size: #{22rpx};
                margin: 0 #{16rpx} 0 0;
                flex-shrink: 0;
                &.large {
                    padding: 0 12rpx;
                    border-radius: 8rpx;
                    color: #FFFFFF;
                }
            }
            .app-composition-name {
                width: #{260rpx};
                font-size: #{28rpx};
                color: #353535;
                &.long-name {
                    width: #{342rpx};
                }
            }
        }
        // .app-composition-type {
        //     padding: #{2rpx 12rpx};
        //     flex-shrink: 0;
        //     border: #{2rpx} solid;
        //     border-radius: #{20rpx};
        //     margin: #{14rpx} 0 0;
        //     font-size: #{22rpx};
        //     display: inline-block;
        // }
        .app-composition-price {
            color: #999999;
            font-size: #{24rpx};
            margin: #{14rpx} 0 #{10rpx};
            text {
                font-size: #{28rpx};
                font-weight: 600;
            }
            .price-int {
                font-size: 40rpx;
            }
        }
        .app-composition-discount {
            color: #999999;
            font-size: #{24rpx};

        }
    }
</style>