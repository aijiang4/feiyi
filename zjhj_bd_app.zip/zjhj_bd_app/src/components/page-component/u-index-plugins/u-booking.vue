<template>
    <u-index-plugins url="/plugins/book/index/index">
        <template v-slot:u-top-name>
            <view class="cross-center u-plugin-top">
                <view class="u-plugin-icon" :style="{'background-color': theme.background,'background-image': 'url('+appImg.icon_home_booking+')'}"></view>
            </view>
        </template>
        <template v-slot:u-body>
            <view class="scroll-list" :class="style === '2' ? 'main-between two-list':'dir-left-nowrap'">
                <app-goods
                  v-for="(goods,idx) in goodsList" :key="goods.id"
                  :index="idx"
                  :showTag="false"
                  :theme="theme"
                  :goods="goods"
                  :c_border_top="16"
                  :scrollWidth="304"
                  :isIndex="true"
                  :showBuyBtn="false"
                  :padding="48"
                  :listStyle="0">
                  </app-goods>
            </view>
        </template>
    </u-index-plugins>
</template>

<script>
import {mapGetters, mapState} from 'vuex';
import uIndexPlugins from '../u-index-plugins/u-index-plugins.vue';
import appGoods from '../../basic-component/app-goods/app-goods.vue';

export default {
    name: "u-booking",
    props: {
        theme: {
            type: Object
        },
        index: {
            type: Number
        },
        page_id: {
            type: Number
        },
        is_required: {
            type: Boolean
        },
        appImg: {
            type: Object,
            default: function() {
                return {
                    plugins_out: ''
                }
            }
        },
        appSetting: {
            type: Object,
            default: function() {
                return {
                    is_show_stock: 1,
                    sell_out_pic: '',
                    is_use_stock: 1
                }
            }
        }
    },
    data() {
        return {
            newData: {},
            tempList: [],
            goodsList: [],
            time: 0,
            style: '1',
            goods_num: 10
        };
    },
    components: {
        uIndexPlugins,
        appGoods
    },
    computed: {
        ...mapGetters('mallConfig', {
            getTheme: 'getTheme',
        }),
        copyList: function() {
            return this.newData;
        }
    },
    methods: {
        loadData() {
            let para = {
                type: this.page_id === 0 ? 'mall' : 'diy',
                key: 'booking',
                page_id: this.page_id,
                index: this.index
            }
            if(this.goods_num) {
                para.goods_num = this.goods_num
            }
            this.$request({
                url: this.$api.index.extra,
                data: para
            }).then(e => {
                this.newData = e.data;
                if (e.code ===0 && e.data && this.page_id === 0) {
                    let storage = this.$storage.getStorageSync('INDEX_MALL');
                    storage.home_pages[this.index].list = this.newData;
                    this.$storage.setStorageSync('INDEX_MALL', storage);
                }
            })
        },
        // 复制而不是引用对象和数组
        cloneData(data) {
            return JSON.parse(JSON.stringify(data));
        },
        // 循环载入
        splitData() {
            if (!this.tempList.length) return;
            let item = this.tempList[0];
            this.goodsList.push(item);
            this.tempList.splice(0, 1);
            if (this.tempList.length) {
                this.timeOut = setTimeout(() => {
                    this.splitData();
                }, 200);
            }
        },
    },

    mounted() {
        let storage = this.$storage.getStorageSync('INDEX_MALL');
        this.style = storage.home_pages[this.index].style;
        this.goods_num = storage.home_pages[this.index].goods_num;
        if (this.is_required) {
            this.loadData();
        } else {
            this.newData = storage.home_pages[this.index].list;
        }
    },
    watch: {
        copyList: {
            handler(newVal) {
                let list = newVal && newVal.list;
                if (this.$validation.empty(list)) return;
                this.tempList = this.cloneData(list);
                this.splitData();
            }
        }
    }
}
</script>

<style scoped lang="scss">
    @import url('./index.scss');
</style>