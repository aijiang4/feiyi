<template>
    <u-index-plugins url="/plugins/advance/index/index">
        <template v-slot:u-top-name>
            <view class="cross-center u-plugin-top">
                <view class="u-plugin-icon" :style="{'background-color': theme.background,'background-image': 'url('+appImg.icon_home_advance+')'}"></view>
            </view>
        </template>
        <template v-slot:u-body>
            <view class="scroll-list" :class="style === '2' ? 'main-between two-list':'dir-left-nowrap'">
                <app-goods
                  v-for="(goods,idx) in goodsList" :key="goods.id"
                  :index="idx"
                  :showTag="false"
                  :theme="theme"
                  :goods="goods"
                  :isUnderLinePrice="true"
                  :c_border_top="16"
                  :scrollWidth="304"
                  :isIndex="true"
                  :showBuyBtn="false"
                  :padding="48"
                  :listStyle="0">
                  </app-goods>
            </view>
        </template>
    </u-index-plugins>
</template>

<script>
import {mapGetters, mapState} from 'vuex';
import uIndexPlugins from '../u-index-plugins/u-index-plugins.vue';
import appGoods from '../../basic-component/app-goods/app-goods.vue';

export default {
    name: "u-advance",
    props: {
        index: Number,
        page_id: Number,
        is_required: Boolean,
        theme: {
            type: Object
        },
        appImg: {
            type: Object,
            default: function() {
                return {
                    plugins_out: ''
                }
            }
        },
        appSetting: {
            type: Object,
            default: function() {
                return {
                    is_show_stock: 1,
                    sell_out_pic: '',
                    is_use_stock: 1
                }
            }
        }
    },
    data() {
        return {
            newData: {},
            tempList: [],
            goodsList: [],
            time: 0,
            style: '1',
            goods_num: 20
        };
    },
    computed: {
        ...mapGetters('mallConfig', {
            getTheme: 'getTheme',
        })
    },
    components: {
        uIndexPlugins,
        appGoods
    },
    methods: {
        loadData() {
            let para = {
                type: this.page_id === 0 ? 'mall' : 'diy',
                key: 'advance',
                page_id: this.page_id,
                index: this.index
            }
            if(this.goods_num) {
                para.goods_num = this.goods_num
            }
            this.$request({
                url: this.$api.index.extra,
                data: para
            }).then(info => {
                if (info.code === 0 && info.data) {
                    this.newData = info.data.list;
                    if (this.page_id === 0) {
                        let storage = this.$storage.getStorageSync('INDEX_MALL');
                        storage.home_pages[this.index].list = this.newData;
                        this.$storage.setStorageSync('INDEX_MALL', storage);
                    }
                }
            })
        },
        // 复制而不是引用对象和数组
        cloneData(data) {
            return JSON.parse(JSON.stringify(data));
        },
        // 循环载入
        splitData() {
            if (!this.tempList.length) return;
            let item = this.tempList[0];
            this.goodsList.push(item);
            this.tempList.splice(0, 1);
            if (this.tempList.length) {
                this.time = setTimeout(() => {
                    this.splitData();
                }, 200);
            }
        },
    },
    mounted() {
        let storage = this.$storage.getStorageSync('INDEX_MALL');
        this.style = storage.home_pages[this.index].style;
        this.goods_num = storage.home_pages[this.index].goods_num;
        if (this.is_required) {
            this.loadData();
        } else {
            this.newData = storage.home_pages[this.index].list;
        }
    },
    watch: {
        newData: {
            handler(newVal) {
                if (this.$validation.empty(newVal)) return;
                this.tempList = this.cloneData(newVal);
                this.splitData();
            },
            immediate: true
        }
    },
    destroyed() {
        clearTimeout(this.time);
    }
}
</script>

<style scoped lang="scss">
    @import url('./index.scss');
</style>
