<template>
    <view class="u-plugins">
        <view class="u-top main-between cross-center" hover-class="u-hover-class" @click="router">
            <slot name="u-top-name"></slot>
            <view class="dir-left-nowrap cross-center">
                <view class="box-grow-0 u-more">更多</view>
                <image class="box-grow-0 u-icon" src="/static/image/icon/arrow-right.png"></image>
            </view>
        </view>
        <scroll-view class="u-bottom" scroll-x>
            <slot name="u-body"></slot>
        </scroll-view>
    </view>
</template>

<script>

export default {
    name: "u-index-plugins",
    props: {
        list: {
            type: Array
        },
        url: {
            type: String
        }
    },
    methods: {
        router() {
            uni.navigateTo({
                url: this.url
            })
        }
    }
}
</script>

<style scoped lang="scss">
    .u-plugins {
        background-color: #ffffff;
        border-radius: 16rpx;
        overflow: hidden;
        padding: 0 24upx;
    }
    .u-top {
        width: 100%;
        height: 72upx;
        border-bottom: 2rpx solid rgba(0,0,0,.1);
    }
    .u-more {
        font-size: 26upx;
        color: #999999;
        margin-right: 12upx;
    }
    .u-icon {
        width: 12upx;
        height: 22upx;
        display: block;
    }
    .u-bottom {
        width: 100%;
    }
</style>