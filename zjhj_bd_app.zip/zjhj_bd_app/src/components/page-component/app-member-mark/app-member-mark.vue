<template>
    <view class="member dir-left-nowrap cross-center main-center"
          :class="[sign == 'gift' ? theme+'-color ' + theme + '-background' : '',mode == 'new'? 'new':'']"
          :style="{width: width,height: height+'rpx',lineHeight: height+'rpx','background-color': sign !== 'gift' && theme ? mode != 'new' ? theme.background_o : theme.background : '','border-radius': mode == 'new' ? height/2 +'rpx' : '8rpx','font-size': font,'color': sign !== 'gift' && theme && mode != 'new' ? theme.background : '#fff'}">会员价</view>
</template>

<script>
    export default {
        name: "app-member-mark",
        props: {
            sign: String,
            width: {
                type: String,
                default() {
                    return `92rpx`;
                }
            },
            mode: {
                type: String,
                default() {
                    return `normal`;
                }
            },
            font: {
                type: String,
                default() {
                    return `20rpx`;
                }
            },
            height: {
                type: Number,
                default() {
                    return 40;
                }
            },
            theme: [Object,String]
        },
    }
</script>

<style scoped lang="scss">
    .member {
        transform: rotateZ(360deg);
        border: 2rpx solid;
        &.new {
            border-top-left-radius: 0!important;
            border: 0;
        }
    }
</style>