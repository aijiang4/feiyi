<template>
    <view class="form-goods-time">
        <view style="padding-bottom:16rpx;font-size: 24rpx" v-if="value  && value.day" class="dir-left-nowrap cross-center">
            <view>预约时间：</view>
            <view v-if="value.is_alone == 1">{{value.new_before}}</view>
            <view v-if="value.is_alone == 0">
                {{value.new_before}}-{{value.new_after}}   共{{value.day}}{{value.place_unit}}
            </view>
        </view>
    </view>
</template>

<script>

export default {
    name: "form-goods-time",
    props: {
        value: Object,
    },
    data() {
        return {
        }
    },
    methods: {
    }
}
</script>

<style scoped>

</style>