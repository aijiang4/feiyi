<template>
    <view class="app-good-shop-recommendation">
        <view class="app-top-title dir-left-nowrap main-between cross-center" v-if="!showGoods && type === 'mch'">
            <view class="app-left dir-left-nowrap cross-center">
                <icon class="icon" type></icon>
                <text>好店推荐</text>
            </view>
            <view class="app-right dir-left-nowrap cross-center">
                <app-jump-button form url="/plugins/mch/list/list">
                    <text>更多</text>
                    <icon class="icon" type></icon>
                </app-jump-button>
            </view>
        </view>
        <view class="app-content" v-if="!showGoods" :style="{padding: `${cPaddingTb}rpx ${cPaddingLf}rpx`}">
            <scroll-view scroll-x class="app-scroll" :style="{border: `${cardStyle == 2 ? `1px solid ${borderColor}`: '0'}`,background:`${cardStyle == 3 ? 'none' : 'white'}`}">
                <view class="app-item" :style="[{marginRight: `${cPaddingCen}rpx`}]"
                      v-for="(item, index) in list"
                      :key="index"
                >
                    <app-jump-button arrangement="column" form :url="'/plugins/mch/shop/shop?mch_id=' + item.id">
                        <image class="app-image" :src="item.picUrl"></image>
                        <text class="app-name u-line-1">
                            {{item.name}}
                        </text>
                    </app-jump-button>
                </view>
            </scroll-view>
        </view>
        <view class="app-goods-shop" v-if="showGoods" :style="{padding: `${cPaddingTb}rpx ${cPaddingLf}rpx`}">
            <view class="app-shop"
                  :style="[{'background-color':`${cardStyle < 3 ? '#ffffff': ''}`,'border': `${cardStyle == 2 ? '2rpx solid #e2e2e2': '0'}`, marginBottom: `${cPaddingCen}rpx`}]"
                  v-for="(item, index) in list" :key="index">
                <view class="app-top dir-top-nowrap">
                    <view class="dir-left-nowrap cross-center" @click.stop="jump(item.id)">
                        <image class="app-image box-grow-0" :src="item.pic_url"></image>
                        <view class="app-name t-omit box-grow-1" style="font-weight: bold">{{ item.name }}</view>
                        <view v-if="item.distance" class="box-grow-0 distance" >距离{{item.distance}}</view>
                        <view v-else class="app-button box-grow-0 main-center cross-center" >进店逛逛</view>
                    </view>
                    <view class="dir-left-nowrap main-between s-n-num cross-center">
                        <view class="dir-top-nowrap box-grow-1 cross-center">
                            <view class="s-label">{{item.favorite_num}}</view>
                            <view class="s-value">关注人数</view>
                        </view>
                        <view class="box-grow-0 s-line"></view>
                        <view class="dir-top-nowrap box-grow-1 cross-center">
                            <view class="s-label">{{item.goods_num}}</view>
                            <view class="s-value">全部商品</view>
                        </view>
                        <view class="box-grow-0 s-line"></view>
                        <view class="dir-top-nowrap box-grow-1 cross-center">
                            <view class="s-label">{{item.order_num}}</view>
                            <view class="s-value"> 已售出 </view>
                        </view>
                    </view>
                </view>
                <!------diy---->
                <view class="app-bottom" v-if="item.goodsList && item.goodsList.length !== 0">
                    <view class="app-scroll dir-left-nowrap cross-center" scroll-x>
                        <view class="app-item"
                              style="height: 100%"
                              :style="[itemStyle(number,item.goodsList.length)]"
                              v-for="(good, number) in item.goodsList" :key="number">
                            <view form
                                  style="width: 100%;height:0;position: relative;padding-bottom: 100%"
                                  @click.native.stop="router_jump(good, item.id)"
                            >
                                <image style="width:100%;height:100%;position: absolute;" class="app-image"
                                       mode="aspectFit" :src="good.picUrl"></image>
                                <text class="app-price" :style="{'color': 'white'}">￥{{ good.price }}</text>
                            </view>
                        </view>
                        <!--囧可-->
                        <view class="app-item"
                              v-if="3 >= item.goodsList.length"
                              style="height: 100%"
                              :style="[itemStyle(number,item.goodsList.length)]"
                              v-for="(good, number) in new Array(3 - item.goodsList.length)" :key="number">
                            <view form
                                  v-show="good"
                                  style="width: 100%;height:0;position: relative;padding-bottom: 100%"
                            >
                                <image style="width:100%;height:100%;position: absolute;" class="app-image"></image>
                            </view>
                        </view>

                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
import {mapGetters, mapState} from 'vuex';

export default {
    name: "app-good-shop-recommendation",

    props: {
        cPaddingTb: {
            type: Number,
            default: 24,
        },
        cPaddingLf: {
            type: Number,
            default: 24,
        },
        cPaddingCen: {
            type: Number,
            default: 20
        },
        borderColor: {
            type: String,
            default: '#62D30C',
        },
        showGoods: {
            type: Boolean,
            default: function () {
                return false;
            },
            required: false
        },
        cardStyle: {
            type: String,
            default: function () {
                    return '1';
                },
                required: false
            },
            type: {
                type: String,
                default() {
                   return 'mch';
                },
                required: false
            },
            backgroundColor: {
                type: String,
                default() {
                   return '#fff';
                },
                required: false
            },
            theme: {
                type: [String, Object],
                required: false
            },
            page_id: {
                type: Number,
                required: false
            },
            index: {
                type: Number,
                required: false
            },
            is_required: {
                type: Boolean,
                required: false
            },
            mch_list: {
                type: Array,
                required: false
            },
            coupon_req: {
                type: Boolean,
                required: false
            }
        },
        computed: {
            ...mapGetters('mallConfig', {
                getVideo: 'getVideo'
            }),
            ...mapState({
                platform: function (state) {
                    return state.gConfig.systemInfo.platform;
                }
            }),
            itemStyle() {
                return (index, length) => {
                    let style = {};
                    if (length < 3 && 0) {
                        Object.assign(style, {width: '224rpx', marginRight: '22rpx'});
                    } else {
                        Object.assign(style, {
                            display: 'flex',
                            flexGrow: 1,
                            flexShrink: 1,
                        });
                        if (index < 2) {
                            Object.assign(style, {marginRight: '22rpx'});
                        }
                    }
                    return style;
                }
            }
        },
	    methods: {
            jump(data) {
                this.$jump({
                    url: `/plugins/mch/shop/shop?mch_id=${data}`,
                    open_type: 'navigate',
                });
            },
            router_jump(data, id) {
                // #ifndef MP-BAIDU
                if (data.goodsWarehouse.video_url && this.getVideo == 1) {
                    // #ifdef MP
                    uni.navigateTo({
                        url: `/pages/goods/video?goods_id=${data.id}&sign=mch`
                    });
                    // #endif
                    // #ifdef H5
                    uni.navigateTo({
                        url: `/plugins/mch/goods/goods?id=${data.id}&mch_id=${id}`,
                    });
                    // #endif
                } else {
                    uni.navigateTo({
                        url: `/plugins/mch/goods/goods?id=${data.id}&mch_id=${id}`,
                    });
                }
                // #endif

                // #ifdef MP-BAIDU
                uni.navigateTo({
                    url: `/plugins/mch/goods/goods?id=${data.id}&mch_id=${id}`,
                });
                // #endif
            },
            loadData() {
                this.$request({
                    url: this.$api.index.extra,
                    data: {
                        type: this.page_id === 0 ?'mall' : 'diy',
                        key: 'mch',
                        page_id: this.page_id,
                        index: this.index,
                        longitude: 0,
                        latitude: 0
                    }
                }).then(e => {
                    this.list = e.data;
                    if (this.page_id === 0) {
                        let storage = this.$storage.getStorageSync('INDEX_MALL');
                        storage.home_pages[this.index].list = this.list;
                        this.$storage.setStorageSync('INDEX_MALL', storage);
                    }
                })
            }
	    },

        data() {
            return {
                list: []
            }
        },

        watch: {
            mch_list: {
                handler(data) {
                    if (this.coupon_req) {
                        this.list = data;
                    }
                },
                deep: true
            }
        },
        mounted() {
            if (this.coupon_req) {
                this.list = this.mch_list;
            } else {
                if (this.is_required) {
                    this.loadData();
                } else {
                    let storage = this.$storage.getStorageSync('INDEX_MALL');
                    this.list = storage.home_pages[this.index].list;
                }
            }
        },
    }
</script>

<style scoped lang="scss">
    .app-good-shop-recommendation {
        width: #{750rpx};

        .distance {
            font-size: 24#{rpx};
            color: #999999;
        }

        .app-top-title {
            width: #{750rpx};
            height: #{80rpx};
            border-bottom: #{1rpx} solid #e2e2e2;
            background-color: #ffffff;

            .icon {
                background-size: 100% 100%;
                background-repeat: no-repeat;
            }

            .app-left {
                height: #{80rpx};

                .icon {
                    width: #{46rpx};
                    height: #{46rpx};
                    background-image: url("../../../static/image/icon/good-shop.png");
                    margin-left: #{24rpx};

                }

                text {
                    font-size: #{26rpx};
                    color: #ff8831;
                    margin-left: #{16rpx};
                }
            }

            .app-right {
                height: #{80rpx};

                .icon {
                    width: #{12rpx};
                    height: #{22rpx};
                    background-image: url("../../../static/image/icon/arrow-right.png");
                    margin-right: #{24rpx};
                }

                text {
                    font-size: #{26rpx};
                    color: #999999;
                    margin-right: #{12rpx};
                }
            }
        }

        .app-content {
            width: #{750rpx};
            padding: #{12rpx} 0;

            .app-scroll {
                //width: #{750rpx};
                padding-top: #{16rpx};
                background:white;

                overflow:hidden;
                white-space: nowrap;
                border-radius: 24#{rpx};
                //height: #{224+20+20+23rpx};
                .app-item:first-child {
                    margin-left: #{16rpx};
                }
                .app-item {
                    display: inline-block;
                    //width: #{224rpx};
                    height: #{224+20+20+24rpx};
                    //margin: 0 #{8rpx};
                    border-radius: #{16rpx};

                    .app-image {
                        width: #{224rpx};
                        height: #{224rpx};
                        border-top-left-radius: #{16rpx};
                        border-top-right-radius: #{16rpx};
                    }

                    .app-name {
                        height: #{24+20+20rpx};
                        /* #ifndef MP-ALIPAY */
                        width: #{189rpx};
                        /* #endif */
                        /* #ifdef MP-ALIPAY */
                        width: #{195rpx};
                        /* #endif */
                        font-size: #{24rpx};
                        color: #353535;
                        line-height: #{24+20+20rpx};
                        display: inline-block;
                        overflow: hidden;
                        text-align: center;
                    }
                }
                .app-item:last-of-type {
                    margin-right: 0 !important;
                }
            }
        }

        .app-goods-shop {
            width: #{750rpx};
            padding: #{20rpx};

            .app-shop {
                //width: #{750-20-20rpx};
                padding: 0 #{24rpx};
                //margin-top: #{20rpx};
                //margin-bottom: #{20rpx};
                overflow: hidden;
                border-radius: #{16rpx};

                .app-top {
                    //width: #{750-20-20-24-24rpx};
                    margin: #{24rpx} 0;

                    > view {
                        width: 100%;
                    }

                    .app-image {
                        width: #{70rpx};
                        height: #{70rpx};
                        border-radius: #{8rpx};
                    }

                    .app-name {
                        font-size: #{32rpx};
                        color: #333333;
                        padding:0 #{20rpx};
                        display: block;
                    }

                    .app-number-title {
                        margin-top: #{12rpx};
                        color: #999999;
                        font-size: #{24rpx};

                        .app-sell {
                            margin-left: #{32rpx};
                        }
                    }

                    .app-button {
                        padding:8#{rpx} 20#{rpx};
                        border: #{1rpx} solid #cccccc;
                        font-size: #{24rpx};
                        color: #666666;
                        line-height: 1;
                        border-radius: #{25rpx};
                    }
                    .s-n-num {
                        padding-top: 20#{rpx};

                        .s-line {
                            width: 1px;
                            height: 56#{rpx};
                            background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0));
                        }

                        .s-label {
                            font-size: 28#{rpx};
                            font-weight: bold;
                            color: #333333;
                        }

                        .s-value {
                            font-size: 20#{rpx};
                            color: #999999;
                        }
                    }
                }

                .app-bottom {
                    ////height: #{210+23rpx};
                    //width: #{750-20-20-24-24rpx};
                    padding-bottom: #{23rpx};

                    .app-scroll {
                        /////height: #{210rpx};
                        //width: #{750-20-20-24-24rpx};
                        white-space: nowrap;
                        ///// margin-bottom: #{23rpx};

                        .app-item {
                            /*background-color: red;*/
                            display: inline-block;
                            //width: #{210rpx};
                            height: #{210rpx};
                            //margin-left: #{8rpx};
                            //margin-right: #{8rpx};
                            position: relative;

                            .app-image {
                                width: 100%;
                                height: #{210rpx};
                                border-radius: 16#{rpx};
                            }

                            .app-price {
                                position: absolute;
                                bottom: 0;
                                left: 0;
                                padding:2#{rpx} 10#{rpx};
                                border-radius: 0 16#{rpx} 0 16#{rpx};
                                font-size: #{20rpx};
                                text-align: center;
                                background-color: rgba(0, 0, 0, 0.5);
                            }
                        }
                    }
                }
            }
            .app-shop:first-of-type {
                margin-top: 0;
            }
            .app-shop:last-of-type {
                margin-bottom: 0 !important;
            }
        }
    }
</style>