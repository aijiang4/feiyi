<template>
    <view class="u-index-cat">
        <view v-for="item in newData" :key="item.relation_id">
            <view class="cross-center cat-top"  @click="route(item.relation_id)">
                <view class="box-grow-1 main-center">
                    <image v-if="item.cat_pic_url" class="cat-pic-url" :src="item.cat_pic_url" ></image>
                    <text class="u-cat-name">{{item.name}}</text>
                </view>
                <view class="cross-center u-more">
                    <text class="u-more-text">更多</text>
                    <image class="u-arrow-right" src="/static/image/icon/arrow-right.png"></image>
                </view>
            </view>
            <view class="goods-list" :class="item.list_style == 3 || listStyle == 3 ? 'dir-left-wrap' : 'main-between flex-wrap'">
                <app-goods
                  v-for="(goods,idx) in item.goods" :key="goods.id"
                  :goods="goods"
                  :no_extra="true"
                  :index="idx"
                  :theme="theme"
                  :padding="15"
                  :listStyle="item.list_style || listStyle"
                  :isUnderLinePrice="isListUnderlinePrice == 1"
                  :c_border_top="16"
                  :c_border_bottom="16"
                  :btnSize="50"
                  :buy="true"
                  :buyBtnImage="goodsImg.cart"
                ></app-goods>
            </view>
        </view>
    </view>
</template>

<script>
    import appGoods from "../../basic-component/app-goods/app-goods.vue";
    import {mapState} from "vuex";

    export default {
        name: "app-index-cat",
        components: {
            appGoods
        },
        props: {
            theme: {
                type: Object
            },
            page_id: {
                type: Number
            },
            index: {
                type: Number
            },
            is_required: {
                type: Boolean
            }
        },
        data() {
            return {
                newData: {}
            }
        },
        methods: {
            route(relation_id) {
                uni.navigateTo({
                    url: `/pages/goods/list?cat_id=${relation_id}`
                });
            },
            loadData() {
                this.$request({
                    url: this.$api.index.extra,
                    data: {
                        type: 'mall',
                        key: 'cat',
                        page_id: this.page_id,
                        index: this.index
                    }
                }).then(e => {
                    this.newData = e.data;
                    if (e.code === 0 && e.data) {
                        let storage = this.$storage.getStorageSync('INDEX_MALL');
                        storage.home_pages[this.index].list = this.newData;
                        this.$storage.setStorageSync('INDEX_MALL', storage);
                    }
                });
            },
            getStorage() {
                let storage = this.$storage.getStorageSync('INDEX_MALL');
                this.newData = storage.home_pages[this.index].list;
            },
            buyProduct(data) {
                this.$emit('buyProduct', data);
            }
        },
        mounted() {
            this.is_required ? this.loadData() : this.getStorage();
        },
        computed: {
            ...mapState({
                goodsImg: state => state.mallConfig.__wxapp_img.goods,
                isListUnderlinePrice: state => state.mallConfig.mall.setting.is_list_underline_price
            })
        },
        filters: {
            listStyle(list_style) {
                return list_style === 1 ? -1 : list_style === 2 ? 2 : list_style === 3 ? 3 : null;
            }
        }
    }
</script>

<style scoped lang="scss">
    .u-index-cat {
        background-color: #ffffff;
        .goods-list {
            padding: 0 15rpx;
        }
    }
    .cat-top {
        height: 80upx;
        padding: 0 24upx;
        position: relative;
    }
    .u-cat-name {
        color: #353535;
        font-size: 28upx;
    }
    .cat-pic-url {
        width: 40upx;
        height: 40upx;
        margin-right: 24upx;
    }
    .u-more {
        position: absolute;
        right: 24upx;
        top: 0;
        z-index: 10;
        height: 100%;
    }
    .u-more-text {
        font-size: 26upx;
        color: #999999;
    }
    .u-arrow-right {
        width: 12upx;
        height: 24upx;
        margin-left: 12upx;
    }
</style>