class formValue {
    constructor({key, label, value, required} = {}) {
        this.key = key;
        this.label = label;
        this.value = value;
        this.required = required || 0;
    }

    add(data) {
        Object.assign(this, data);
    }

    getObject() {
        return this;
        console.log(this,'33333333333333333333');
        let {key, label, value, required} = this;
        return {
            key, label, value, required
        };
    }
}


export default formValue;
