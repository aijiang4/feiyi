// #ifdef MP-WEIXIN
export const platform = 'wxapp';
// #endif

// #ifdef MP-ALIPAY
export const platform = 'aliapp';
// #endif

// #ifdef MP-BAIDU
export const platform = 'bdapp';
// #endif

// #ifdef MP-TOUTIAO
export const platform = 'ttapp';
// #endif

// #ifdef H5
export const platform = 'mobile';
// #endif
