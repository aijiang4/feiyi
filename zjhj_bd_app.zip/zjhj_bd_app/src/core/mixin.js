export default {
	install(Vue) {
		Vue.mixin({
			onLoad(options) {
				console.log('全局混入的钩子函数');
			},
			data() {
				return {
					shareTimelineData: {
						app_share_title: null,
						app_share_pic: null,
						query: {}
					}
				};
			},
			// #ifdef MP-WEIXIN
			onShareTimeline() {
				return this.$shareTimeline(this.shareTimelineData);
			},
			// #endif
			methods: {
				/**
				 * 价格添加单位
				 * @param {float} price 价格
				 * @param {string} unit 单位
				 * @param {string} position 单位位置 prev--前缀  after--后缀
				 * @param {boolean}  is_free
				 * @return {string}       
				 */
				priceUnit(price, unit = '￥', position = 'prev', is_free = true) {
					if (is_free && Number(price) === 0) {
						return '免费';
					}
					if (position === 'prev') {
						return unit + price;
					} else {
						return price + unit;
					}
				},
								
				handlePrice(price,number) {
					price = price.toString();
					let bigger = false;
					if(price > 10000) {
						bigger = true;
						price = (+price / 10000).toFixed(number ? number : 2);
						console.log(number,price)
					}
					let m = price.match(/(\d+)(.\d*)?$/);
					let priceInt = m ? m[1] : '';
					let priceFloat = ''
					if (m && m[2] && m[2] !== '.') {
		                priceFloat =  m[2]
		            }
		            if(bigger) {
		            	priceFloat = priceFloat + 'w'
		            }
		            priceInt = price == 0 ? '免费' : price > 0 ? priceInt : price;
		            priceFloat = price == 0 ? '' : priceFloat;
					return {priceInt: priceInt,priceFloat: priceFloat}
				},
				
				/**
				 * 给价格附加上正负号
				 * @param {boolean} is_true	是否为正数
				 * @param {float|null} price	可为空
				 * @return {string}
				 */
				priceSymbol(is_true, price = '') {
					return (is_true ? '+' : '-') + price;
				},
				
				/**
				 * 正负数的颜色
				 * @param {boolean} is_true 是否为正数
				 * @param {string} true_color 正数的颜色
				 * @param {string} false_color 负数的颜色
				 * @return {string}      
				 */
				priceColor(is_true, true_color = '#ff4544', false_color = '#3fc24c') {
					return is_true ? true_color : false_color;
				}
			}
		})
	}
}
