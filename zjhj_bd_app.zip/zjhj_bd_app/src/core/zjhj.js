export default {
	login(args) {
		return new Promise((resolve, reject) => {
			let data = {
				scopes: args.scopes || 'auth_base',
				success(e) {
					if (typeof args.success === 'function') {
						args.success(e);
					}
					resolve(e);
				},
				fail(e) {
					if (typeof args.fail === 'function') {
						args.fail(e);
					}
					reject(e);
				}
			}
			// #ifdef MP-BAIDU
			swan.getLoginCode(data);
			// #endif
			// #ifndef MP-BAIDU
			uni.login(data)
			// #endif
		});
	}
}