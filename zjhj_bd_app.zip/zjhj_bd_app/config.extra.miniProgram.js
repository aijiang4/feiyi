module.exports = {
    externals: {
        'siteInfo': 'commonjs2 ../siteinfo.js',
        'appVersion': 'commonjs2 ../version.js'
    },
    copy: []
};
